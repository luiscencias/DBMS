# Project-2
Project 2 for CSCE 315

Part 1: Design Documentation
- see wiki log

Part 2: Parser 
The java.parser class takes the input from the input.txt file and prints the results to output.txt

To compile use:
javac -cp "antlr-4.7.1-complete.jar" *.java

To run:
java -cp ".:antlr-4.7.1-complete.jar"
